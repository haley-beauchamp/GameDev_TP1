using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreHUD : MonoBehaviour
{
    public static ScoreHUD instance;
    public int Score = 0;
    public Text ScoreText;

    void Awake()
    {
        instance = this;
    }

    void Start()
    {
        ScoreText.text = "Score: " + Score.ToString();
    }

    public void IncreaseScore(int increment)
    {
        Score = Score + increment;
        ScoreText.text = "Score: " + Score.ToString();
    }

}

