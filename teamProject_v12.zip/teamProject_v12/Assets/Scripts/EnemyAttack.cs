using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAttack : MonoBehaviour
{
    Rigidbody2D enemy;
    public int enemyDamage = 1;


    void Start()
    {
        enemy = GetComponent<Rigidbody2D>();
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            playerHealth.playerHP = playerHealth.playerHP - 1;
            Debug.Log("Player took damage");
        }
    }
}
